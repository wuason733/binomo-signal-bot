# Bot de señales para Binomo
Este bot envía señales automáticas al grupo de Telegram.
